/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Produto;


import java.sql.*;


public class ProdutoDal {

    private static Connection con;

    public static void conecta() {
        try {
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");

            con = DriverManager.getConnection(
                "jdbc:ucanaccess://C:/Users/aluno/Downloads/cfa6281cbd93-c18e8d4b8cef4fc7bbb278714a1f47d0/Aula27/Livros.mdb"
            );

            System.out.println("Conexao realizada com sucesso!");

        } catch (Exception e) {
            System.out.println("Erro na conexao: " + e.getMessage());
        }
    }

    public static void desconecta() {
        try {
            if (con != null && !con.isClosed()) {
                con.close();
            }
        } catch (Exception e) {
            System.out.println("Erro ao desconectar: " + e.getMessage());
        }
    }
    
    
public static void insereProduto() {
    String sql = "INSERT INTO TabProduto "
            + "(codigo, descricao, fabricante, qtd, preco) "
            + "VALUES (?, ?, ?, ?, ?)";

    try {
        conecta();

        if (con == null || con.isClosed()) {
            System.out.println("Conexao indisponivel!");
            return;
        }

        PreparedStatement st = con.prepareStatement(sql);

        st.setString(1, Produto.getCodigo());
        st.setString(2, Produto.getDescricao());
        st.setString(3, Produto.getFabricante());
        st.setString(4, Produto.getQtd());
        st.setString(5, Produto.getPreco());

        st.executeUpdate();
        st.close();

        System.out.println("Produto cadastrado com sucesso!");

    } catch (Exception e) {
        System.out.println("Erro ao cadastrar: " + e.getMessage());
    } finally {
        desconecta();
    }
    
    
   
}

public static void consultaProduto() 
    
{

    String sql = "SELECT * FROM TabProduto WHERE codigo = ?";

    try {
        conecta();

        if (con == null || con.isClosed()) {
            System.out.println("Conexao indisponivel!");
            return;
        }

        PreparedStatement st = con.prepareStatement(sql);

        st.setString(1, Produto.getCodigo());

        ResultSet rs = st.executeQuery();

        if (rs.next()) {

            Produto.setDescricao(rs.getString("descricao"));
            Produto.setFabricante(rs.getString("fabricante"));
            Produto.setQtd(rs.getString("qtd"));
            Produto.setPreco(rs.getString("preco"));

            System.out.println("Produto encontrado!");

        } else {
            System.out.println("Produto nao encontrado!");
        }

        rs.close();
        st.close();

    } catch (Exception e) {
        System.out.println("Erro na consulta: " + e.getMessage());
    } finally {
        desconecta();
    }
    
}

public static void alteraProduto()
{
    String sql = "UPDATE TabProduto "
            + "SET descricao = ?, fabricante = ?, "
            + "qtd = ?, preco = ? "
            + "WHERE codigo = ?";

    try {
        conecta();

        if (con == null || con.isClosed()) {
            System.out.println("Conexao indisponivel!");
            return;
        }

        PreparedStatement st = con.prepareStatement(sql);

        st.setString(1, Produto.getDescricao());
        st.setString(2, Produto.getFabricante());
        st.setString(3, Produto.getQtd());
        st.setString(4, Produto.getPreco());
        st.setString(5, Produto.getCodigo());

        int linhas = st.executeUpdate();

        if (linhas > 0) {
            System.out.println("Produto alterado com sucesso!");
        } else {
            System.out.println("Produto nao encontrado!");
        }

        st.close();

    } catch (Exception e) {
        System.out.println("Erro ao alterar: " + e.getMessage());
    } finally {
        desconecta();
    }
}


public static void excluiProduto() {

    String sql = "DELETE FROM TabProduto WHERE codigo = ?";

    try {
        conecta();

        if (con == null || con.isClosed()) {
            System.out.println("Conexao indisponivel!");
            return;
        }

        PreparedStatement st = con.prepareStatement(sql);

        st.setString(1, Produto.getCodigo());

        int linhas = st.executeUpdate();

        if (linhas > 0) {
            System.out.println("Produto excluido com sucesso!");
        } else {
            System.out.println("Produto nao encontrado!");
        }

        st.close();

    } catch (Exception e) {
        System.out.println("Erro ao excluir: " + e.getMessage());
    } finally {
        desconecta();
    }
}


 

    
}

    
