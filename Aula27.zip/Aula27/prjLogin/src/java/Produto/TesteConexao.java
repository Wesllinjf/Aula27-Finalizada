
package Produto;

public class TesteConexao {

    public static void main(String[] args) {

        Produto.setCodigo("101");

        ProdutoDal.consultaProduto();

    }
}
