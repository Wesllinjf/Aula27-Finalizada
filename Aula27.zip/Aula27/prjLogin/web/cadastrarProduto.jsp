

<%@page import="Produto.Produto"%>
<%@page import="Produto.ProdutoDal"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>

<%
    if ("POST".equalsIgnoreCase(request.getMethod())) {

        String codigo = request.getParameter("codigo");
        String descricao = request.getParameter("descricao");
        String fabricante = request.getParameter("fabricante");
        String qtd = request.getParameter("qtd");
        String preco = request.getParameter("preco");

        Produto.setCodigo(codigo);
        Produto.setDescricao(descricao);
        Produto.setFabricante(fabricante);
        Produto.setQtd(qtd);
        Produto.setPreco(preco);

        ProdutoDal.insereProduto();
    }
%>


<!DOCTYPE html>
<html lang=pt-BR"">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
    </head>
    <body>
        <h1>Cadastar Produto</h1>
        
        <form action="cadastrarProduto.jsp" method="post"></form>
        
        <p>
            <label for="codigo">Código:</label>
            <input type="number" id="codigo"
                   name="codigo" min="0"
                   step="1" required>
        </p>
        
        <p>
            <label for="descricao">Descrição:</label>
            <input type="text" id="descricao"
                   name="descricao" required>
        </p>

        <p>
            <label for="fabricante">Fabricante:</label>
            <input type="text" id="fabricante"
                   name="fabricante" required>
        </p>

        <p>
            <label for="qtd">Quantidade:</label>
            <input type="number" id="qtd"
                   name="qtd" min="0"
                   step="1" required>
        </p>

        <p>
            <label for="preco">Preço:</label>
            <input type="number" id="preco"
                   name="preco" min="0"
                   step="0.01" required>
        </p>

        <button type="submit">Cadastrar</button>

    </form>

    <p>
        <a href="menuProduto.jsp">Voltar ao menu</a>
    </p>

    </body>
</html>
