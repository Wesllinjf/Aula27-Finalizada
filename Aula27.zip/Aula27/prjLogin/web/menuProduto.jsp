
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Cadastro de Produtos</title>
</head>
<body>

    <h1>Sistema de Cadastro de Produtos</h1>

    <h2>Menu Principal</h2>

    <p>Escolha uma operação:</p>

    <ul>
        <li>Inserir Produto</li>
        <li>Consultar Produto</li>
        <li>Alterar Produto</li>
        <li>Excluir Produto</li>
    </ul>

</body>
</html>
