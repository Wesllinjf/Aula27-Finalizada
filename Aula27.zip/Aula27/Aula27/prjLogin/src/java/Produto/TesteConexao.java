
package Produto;

public class TesteConexao {

    public static void main(String[] args) {

        // Define o codigo do produto que queremos buscar
        Produto.setCodigo("103");

        // Consulta o produto no banco Access
        ProdutoDal.consultaProduto();

        // Mostra os dados encontrados
        System.out.println("Codigo: " + Produto.getCodigo());
        System.out.println("Descricao: " + Produto.getDescricao());
        System.out.println("Fabricante: " + Produto.getFabricante());
        System.out.println("Quantidade: " + Produto.getQtd());
        System.out.println("Preco: " + Produto.getPreco());
    }
}
