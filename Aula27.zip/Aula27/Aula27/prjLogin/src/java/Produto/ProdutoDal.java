package Produto;

import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class ProdutoDal {

    private static Connection con;

    // Caminho do banco no computador de casa.
    private static final String CAMINHO_BANCO =
            "C:/Users/Renan/Downloads/Aula27/Aula27/Livros.mdb";

    public static void conecta() {
        con = null;

        try {
            File arquivo = new File(CAMINHO_BANCO);
            if (!arquivo.isFile()) {
                System.err.println("Banco nao encontrado: " + CAMINHO_BANCO);
                return;
            }

            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");

            // IMPORTANTE: LoginDAL usa usuario e senha vazios.
            // O cadastro deve usar as MESMAS credenciais para evitar
            // "invalid authorization specification - not found: Admin".
            con = DriverManager.getConnection(
                    "jdbc:ucanaccess://" + CAMINHO_BANCO, "", ""
            );

            System.out.println("Conexao realizada com sucesso!");

        } catch (Exception e) {
            System.err.println("Erro na conexao: " + e.getMessage());
            e.printStackTrace();
            con = null;
        }
    }

    public static void desconecta() {
        try {
            if (con != null && !con.isClosed()) {
                con.close();
            }
        } catch (Exception e) {
            System.err.println("Erro ao desconectar: " + e.getMessage());
            e.printStackTrace();
        } finally {
            con = null;
        }
    }

    public static boolean insereProduto() {
        String sql = "INSERT INTO TabProduto "
                + "(codigo, descricao, fabricante, qtd, preco) "
                + "VALUES (?, ?, ?, ?, ?)";

        try {
            conecta();

            if (con == null || con.isClosed()) {
                System.err.println("Conexao indisponivel para cadastro!");
                return false;
            }

            try (PreparedStatement st = con.prepareStatement(sql)) {
                st.setString(1, Produto.getCodigo());
                st.setString(2, Produto.getDescricao());
                st.setString(3, Produto.getFabricante());
                st.setString(4, Produto.getQtd());
                st.setString(5, Produto.getPreco());

                int linhas = st.executeUpdate();
                System.out.println("Produtos cadastrados: " + linhas);
                return linhas > 0;
            }

        } catch (Exception e) {
            System.err.println("Erro ao cadastrar: " + e.getMessage());
            e.printStackTrace();
            return false;
        } finally {
            desconecta();
        }
    }

    public static boolean consultaProduto() {
        String sql = "SELECT * FROM TabProduto WHERE codigo = ?";

        try {
            conecta();

            if (con == null || con.isClosed()) {
                System.err.println("Conexao indisponivel para consulta!");
                return false;
            }

            try (PreparedStatement st = con.prepareStatement(sql)) {
                st.setString(1, Produto.getCodigo());

                try (ResultSet rs = st.executeQuery()) {
                    if (rs.next()) {
                        Produto.setDescricao(rs.getString("descricao"));
                        Produto.setFabricante(rs.getString("fabricante"));
                        Produto.setQtd(rs.getString("qtd"));
                        Produto.setPreco(rs.getString("preco"));

                        System.out.println("Produto encontrado!");
                        return true;
                    }
                }
            }

            System.out.println("Produto nao encontrado!");
            return false;

        } catch (Exception e) {
            System.err.println("Erro na consulta: " + e.getMessage());
            e.printStackTrace();
            return false;
        } finally {
            desconecta();
        }
    }

    public static void alteraProduto() {
        String sql = "UPDATE TabProduto "
                + "SET descricao = ?, fabricante = ?, qtd = ?, preco = ? "
                + "WHERE codigo = ?";

        try {
            conecta();

            if (con == null || con.isClosed()) {
                System.err.println("Conexao indisponivel para alteracao!");
                return;
            }

            try (PreparedStatement st = con.prepareStatement(sql)) {
                st.setString(1, Produto.getDescricao());
                st.setString(2, Produto.getFabricante());
                st.setString(3, Produto.getQtd());
                st.setString(4, Produto.getPreco());
                st.setString(5, Produto.getCodigo());

                int linhas = st.executeUpdate();
                if (linhas > 0) {
                    System.out.println("Produto alterado com sucesso!");
                } else {
                    System.out.println("Produto nao encontrado para alteracao!");
                }
            }

        } catch (Exception e) {
            System.err.println("Erro ao alterar: " + e.getMessage());
            e.printStackTrace();
        } finally {
            desconecta();
        }
    }

    public static boolean excluiProduto() {
        String sql = "DELETE FROM TabProduto WHERE codigo = ?";

        try {
            conecta();

            if (con == null || con.isClosed()) {
                System.err.println("Conexao indisponivel para exclusao!");
                return false;
            }

            try (PreparedStatement st = con.prepareStatement(sql)) {
                st.setString(1, Produto.getCodigo());

                int linhas = st.executeUpdate();
                if (linhas > 0) {
                    System.out.println("Produto excluido com sucesso!");
                    return true;
                }
            }

            System.out.println("Produto nao encontrado para exclusao!");
            return false;

        } catch (Exception e) {
            System.err.println("Erro ao excluir: " + e.getMessage());
            e.printStackTrace();
            return false;
        } finally {
            desconecta();
        }
    }
}
