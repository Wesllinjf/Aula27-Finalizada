/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Produto;


public class Produto {
    
    private static String codigo;
    private static String descricao;
    private static String fabricante;
    private static String qtd;
    private static String preco;
    
    public static String getCodigo()
    {
        return codigo;
    }
    
    public static void setCodigo(String codigo)
    {
        Produto.codigo = codigo;
    }
     
    public static String getDescricao()
    {
        return descricao;
    }
      
    public static void setDescricao(String descricao)
    {
        Produto.descricao = descricao;
    }
    
    public static String getFabricante() {
        return fabricante;
    }

    public static void setFabricante(String fabricante) {
        Produto.fabricante = fabricante;
    }

    public static String getQtd() {
        return qtd;
    }

    public static void setQtd(String qtd) {
        Produto.qtd = qtd;
    }

    public static String getPreco() {
        return preco;
    }

    public static void setPreco(String preco) {
        Produto.preco = preco;
    }
    
}
