

<%@page import="Produto.Produto"%>
<%@page import="Produto.ProdutoDal"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>

<%
    if ("POST".equalsIgnoreCase(request.getMethod())) {

        String codigo = request.getParameter("codigo");

        Produto.setCodigo(codigo);

        ProdutoDal.consultaProduto();

        boolean encontrado = ProdutoDal.consultaProduto();

        if (encontrado) {

            out.println("<h2>Dados do Produto</h2>");

            out.println("<p>Codigo: " + Produto.getCodigo() + "</p>");
            out.println("<p>Descricao: " + Produto.getDescricao() + "</p>");
            out.println("<p>Fabricante: " + Produto.getFabricante() + "</p>");
            out.println("<p>Quantidade: " + Produto.getQtd() + "</p>");
            out.println("<p>Preco: " + Produto.getPreco() + "</p>");

        } else {

            out.println("<p style='color: red;'>Produto nao encontrado!</p>");

        }

    }
%>
    
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Consultar Produto</title>
</head>
<body>

    <h1>Consultar Produto</h1>

    <form action="consultarProduto.jsp" method="post">

        <p>
            <label for="codigo">Código:</label>
            <input type="number"
                   id="codigo"
                   name="codigo"
                   min="0"
                   step="1"
                   required>
        </p>

        <button type="submit">Consultar</button>

    </form>

    <p>
        <a href="menuProduto.jsp">Voltar ao menu</a>
    </p>

</body>
</html>
