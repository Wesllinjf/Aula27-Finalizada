

<%@page import="Produto.Produto"%>
<%@page import="Produto.ProdutoDal"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>

<%
    if ("POST".equalsIgnoreCase(request.getMethod())) {

        
        String codigo = request.getParameter("codigo");

        Produto.setCodigo(codigo);

        boolean excluido = ProdutoDal.excluiProduto();

        if (excluido) {
            out.println("<h2 style='color:green;'>Produto excluido com sucesso!</h2>");
        } else {
            out.println("<h2 style='color:red;'>Produto nao encontrado ou erro ao excluir!</h2>");
        }


    }
%>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Excluir Produto</title>
</head>
<body>

    <h1>Excluir Produto</h1>

    <form action="excluirProduto.jsp" method="post">

        <p>
            <label for="codigo">Código do Produto:</label>
            <input type="number"
                   id="codigo"
                   name="codigo"
                   min="0"
                   step="1"
                   required>
        </p>

        <button type="submit"
                onclick="return confirm('Tem certeza que deseja excluir este produto?');">
            Excluir
        </button>

    </form>

    <p>
        <a href="menuProduto.jsp">Voltar ao menu</a>
    </p>

</body>
</html>
