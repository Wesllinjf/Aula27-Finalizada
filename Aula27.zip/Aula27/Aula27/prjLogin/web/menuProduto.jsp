
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Cadastro de Produtos</title>
</head>
<body>

    <h1>Sistema de Cadastro de Produtos</h1>

    <h2>Menu Principal</h2>

    <p>Escolha uma operação:</p>

   
        
<ul>
    <li>
        <a href="cadastrarProduto.jsp">Inserir Produto</a>
    </li>

    <li>
        <a href="consultarProduto.jsp">Consultar Produto</a>
    </li>

    <li>
        <a href="alterarProduto.jsp">Alterar Produto</a>
    </li>

    <li>
        <a href="excluirProduto.jsp">Excluir Produto</a>
    </li>
</ul>

   

</body>
</html>
